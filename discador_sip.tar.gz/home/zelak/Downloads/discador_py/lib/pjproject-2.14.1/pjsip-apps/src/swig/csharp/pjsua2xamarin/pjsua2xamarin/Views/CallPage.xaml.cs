﻿using System;
using Xamarin.Forms;

namespace pjsua2xamarin
{    
    public partial class CallPage : ContentPage
    {    
        public CallPage ()
        {
            InitializeComponent ();
        }
    }
}

