//
//  main.m
//  ipjsua
//
//  Created by Liong Sauw Ming on 13/3/13.
//  Copyright (c) 2013 Teluu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ipjsuaAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ipjsuaAppDelegate class]));
    }
}
